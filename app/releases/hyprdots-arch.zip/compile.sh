#!/bin/bash

cp waybar ~/.config/waybar
cp hypr ~/.config/hypr
cp wallpapers ~/.config/wallpapers
